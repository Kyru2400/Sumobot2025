#ifndef ESP32_SHARP_IR_H
#define ESP32_SHARP_IR_H

#include <Arduino.h>

#if defined(ESP32)
  #include <driver/adc.h>     // brings in ADC_11db and its enum type
  // Create a portable alias that matches your core's ADC attenuation type
  using adc_atten_any_t = decltype(ADC_11db);
#else
  // Fallback for non-ESP32 builds (keeps library testable)
  using adc_atten_any_t = int;
  #ifndef ADC_11db
    #define ADC_11db ((adc_atten_any_t)3)
  #endif
#endif

class ESP32SharpIR {
public:
  enum sensorCode : uint8_t { GP2Y0A41SK0F=0, GP2Y0A21YK0F=1, GP2Y0A02YK0F=2 };

  static constexpr uint8_t ANALOG_RESOLUTION = 12;

  ESP32SharpIR(sensorCode _sensorType, uint8_t _sensorPin);

  // NOTE: signature now uses the portable alias
  void     begin(adc_atten_any_t atten = ADC_11db);

  void     setFilterRate(float rate);
  void     setMinInterval(uint16_t ms);
  void     setSamples(uint8_t count, uint8_t gapMs);

  bool     poll();
  float    last()           const { return average; }
  uint8_t  lastRaw()        const { return lastRawCm; }
  uint32_t lastSampleMs()   const { return lastTime; }

  float    getDistanceFloat(bool /*avoidBurstRead*/ = false) { poll(); return last(); }
  uint8_t  getDistance     (bool /*avoidBurstRead*/ = false) { poll(); return lastRaw(); }

private:
  uint8_t  computeDistanceCm(uint16_t adcRaw) const;
  uint16_t readADC() const;

  sensorCode sensorType;
  uint8_t    pin;

  uint32_t   lastTime;
  uint16_t   minIntervalMs;

  uint8_t    samples;
  uint8_t    sampleGapMs;

  float      alpha;
  float      average;
  uint8_t    lastRawCm;
};

#endif // ESP32_SHARP_IR_H
