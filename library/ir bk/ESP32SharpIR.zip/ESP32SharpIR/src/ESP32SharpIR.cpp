#include "ESP32SharpIR.h"

ESP32SharpIR::ESP32SharpIR(sensorCode _sensorType, uint8_t _sensorPin)
: sensorType(_sensorType),
  pin(_sensorPin),
  lastTime(0),
  minIntervalMs(25),
  samples(4),
  sampleGapMs(3),
  alpha(0.20f),
  average(NAN),
  lastRawCm(0)
{}

void ESP32SharpIR::begin(adc_atten_any_t atten) {
  analogReadResolution(ANALOG_RESOLUTION);
  analogSetPinAttenuation(pin, atten);  // works for both adc_atten_t and adc_attenuation_t cores
  pinMode(pin, INPUT);
}

void ESP32SharpIR::setFilterRate(float rate) {
  if (rate > 0.0f && rate < 1.0f) alpha = rate;
}

void ESP32SharpIR::setMinInterval(uint16_t ms) {
  if (ms < 5) ms = 5; // don't go crazy-fast
  minIntervalMs = ms;
}

void ESP32SharpIR::setSamples(uint8_t count, uint8_t gapMs) {
  samples = (count == 0) ? 1 : count;
  sampleGapMs = gapMs;
}

uint16_t ESP32SharpIR::readADC() const {
  // Average N samples with a small gap for stability
  uint32_t acc = 0;
  for (uint8_t i = 0; i < samples; ++i) {
    acc += analogRead(pin);          // 0..4095 (12-bit)
    if (i + 1 < samples && sampleGapMs) delay(sampleGapMs);
  }
  return (uint16_t)(acc / samples);
}

uint8_t ESP32SharpIR::computeDistanceCm(uint16_t r) const {
  float distance = 0.0f;

  switch (sensorType) {
    case GP2Y0A41SK0F: {
      // 4–30 cm (short)
      // Community fit: d ≈ 2076 / (r - 11)
      if (r <= 11) distance = 31.0f;                 // treat as too far (OOR high)
      else         distance = 2076.0f / (r - 11.0f);
      if (distance > 30.0f) return 31;               // TOO FAR sentinel
      if (distance < 4.0f)  return 3;                // TOO NEAR sentinel
      return (uint8_t)distance;
    }

    case GP2Y0A21YK0F: {
      // 10–80 cm (mid)
      // Common fit: d ≈ 28400 / r
      if (r == 0) distance = 81.0f;                  // guard div-by-zero
      else        distance = 28400.0f / (float)r;
      if (distance > 80.0f) return 81;               // TOO FAR sentinel
      if (distance < 10.0f) return 9;                // TOO NEAR sentinel
      return (uint8_t)distance;
    }

    case GP2Y0A02YK0F: {
      // 20–150 cm (long)
      // Community fit: d ≈ 9462 / (r - 16.92)
      if (r <= 17) distance = 151.0f;                // treat as too far
      else         distance = 9462.0f / (r - 16.92f);
      if (distance > 150.0f) return 151;             // TOO FAR sentinel
      if (distance < 20.0f)  return 19;              // TOO NEAR sentinel
      return (uint8_t)distance;
    }
  }

  // Should not hit
  return 0;
}

bool ESP32SharpIR::poll() {
  const uint32_t now = millis();
  if ((uint32_t)(now - lastTime) < minIntervalMs) return false; // not time yet

  // Time to take a sample
  lastTime = now;

  const uint16_t r = readADC();
  const uint8_t  cm = computeDistanceCm(r);
  lastRawCm = cm;

  // Convert to float for EMA (sentinels still smoothed as numbers; that's fine)
  const float rawF = (float)cm;

  if (isnan(average)) {
    average = rawF;          // initialize EMA
  } else {
    average = alpha * rawF + (1.0f - alpha) * average;
  }

  return true;
}
